
public interface Vehicle {

  public String getType();
}
