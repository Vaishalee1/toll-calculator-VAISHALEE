
public class Motorbike implements Vehicle {
  @Override
  public String getType() {
    return "Motorbike";
  }
}
